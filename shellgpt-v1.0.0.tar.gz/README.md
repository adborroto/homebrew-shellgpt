# shellgpt
Using OpenAI from your terminal
